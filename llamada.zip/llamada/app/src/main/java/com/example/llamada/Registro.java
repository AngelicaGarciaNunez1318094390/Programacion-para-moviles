package com.example.llamada;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class Registro extends AppCompatActivity {

    public EditText editextnombre;
    public EditText editextcontraseña;
    public EditText editextfecha;
    public EditText editxtnumerotel;
    public Button botonregistrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        editextnombre = (EditText) findViewById(R.id.edttxtnombre);
        editextcontraseña = (EditText) findViewById(R.id.edttxtcontraseñar);
        editextfecha = (EditText) findViewById(R.id.edttxtfecha);
        editxtnumerotel = (EditText) findViewById(R.id.edttxtnumerotel);
        botonregistrar = (Button) findViewById(R.id.btnregistrarte2);

        Bundle parametros = this.getIntent().getExtras();
        String datos = parametros.getString("datos");

        Button btn1 = (Button) findViewById(R.id.btnregistrarte2);
        btn1.setOnClickListener(new View.OnClickListener() {
            AlertDialog.Builder dialog;
            @Override
            public void onClick(View v) {
                if (editextnombre.getText().toString().length() == 0) {
                    dialog = new AlertDialog.Builder(Registro.this);
                    dialog.setTitle("Error");
                    dialog.setMessage("Ingresar el nombre");
                    dialog.setCancelable(false);
                    dialog.setPositiveButton("Cerrar", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogo, int id) {
                            dialogo.cancel();
                            editextnombre.requestFocus();
                        }
                    });
                    dialog.show();
                } else {
                    if (editextcontraseña.getText().toString().length() == 0) {
                        dialog = new AlertDialog.Builder(Registro.this);
                        dialog.setTitle("Error");
                        dialog.setMessage("Ingresar la contraseña");
                        dialog.setCancelable(false);
                        dialog.setPositiveButton("Cerrar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogo, int id) {
                                dialogo.cancel();
                                editextnombre.requestFocus();
                            }
                        });
                        dialog.show();
                    } else {
                        if (editextfecha.getText().toString().length() == 0) {
                            dialog = new AlertDialog.Builder(Registro.this);
                            dialog.setTitle("Error");
                            dialog.setMessage("Ingresar la fecha");
                            dialog.setCancelable(false);
                            dialog.setPositiveButton("Cerrar", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialogo, int id) {
                                    dialogo.cancel();
                                    editextnombre.requestFocus();
                                }
                            });
                            dialog.show();
                        } else {
                            if (editxtnumerotel.getText().toString().length() == 0) {
                                dialog = new AlertDialog.Builder(Registro.this);
                                dialog.setTitle("Error");
                                dialog.setMessage("Ingresar el número telefónico");
                                dialog.setCancelable(false);
                                dialog.setPositiveButton("Cerrar", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialogo, int id) {
                                        dialogo.cancel();
                                        editextnombre.requestFocus();
                                    }
                                });
                                dialog.show();
                            } else {
                                Intent intent = new Intent(v.getContext(), IniciarSesion.class);
                                startActivityForResult(intent, 0);
                                Intent i=new Intent(v.getContext(), llamar.class);
                                startActivity(i);
                                botonregistrar.setText("Registrado");
                            }
                        }
                    }
                }
            }
        });

    }
}

/*else {
        Intent intent = new Intent(v.getContext(), IniciarSesion.class);
        startActivityForResult(intent, 0);
        }*/
